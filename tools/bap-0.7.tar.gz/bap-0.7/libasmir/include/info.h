/*
 Owned and copyright BitBlaze, 2007. All rights reserved.
 Do not copy, disclose, or distribute without explicit written
 permission.
*/
#ifndef _INFO_H
#define _INFO_H
char *libasmir_version(void);
#endif
