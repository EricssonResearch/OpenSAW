#include "trace_v41.h"

Trace_v41::Trace_v41(ifstream * tracefile) : Trace(tracefile) { }



